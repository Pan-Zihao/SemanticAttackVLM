
<br>

<div align=center>
<h1 align="center">
<img src="docs/figures/logo.png" width="50"> AEL Algorithm Evolution using Large Language Model
</h1>

  [English Version 英文版本](./README.md)

[![Github][Github-image]][Github-url]
[![License][License-image]][License-url]
[![Releases][Releases-image]][Releases-url] 
[![Web Demo][Installation-image]][Web Demo-url]
[![Wiki][Wiki-image]][Wiki-url]


[Github-image]: https://img.shields.io/badge/github-12100E.svg?style=flat-square
[License-image]: https://img.shields.io/badge/License-MIT-orange?style=flat-square
[Releases-image]: https://img.shields.io/badge/Release-Version_1.0-blue?style=flat-square
[Installation-image]: https://img.shields.io/badge/Web_Demo-Version_1.0-blue?style=flat-square
[Wiki-image]: https://img.shields.io/badge/Docs-参考文档-black?style=flat-square


[Github-url]: https://github.com/FeiLiu36/AEL
[License-url]: https://github.com/FeiLiu36/AEL/blob/main/LICENSE
[Releases-url]: https://github.com/FeiLiu36/AEL/releases
[Web Demo-url]: https://github.com/FeiLiu36/AEL/ael/app/
[Wiki-url]: https://github.com/FeiLiu36/AEL/tree/main/docs



</div>
<br>

###### 

这段代码为自动算法设计提供了**进化计算 + 大型语言模型** 用于算法设计的框架。

<img src="./docs/figures/ael.jpg" alt="ael" width="600" height="280">

## 简介

对复杂的搜索和优化问题来说，启发式方法是不可或缺的。然而，手动设计启发式方法是繁琐的，需要相当多的人类直觉和经验。

AEL引入了一种新颖的范式，利用大型语言模型（LLMs）和进化计算（EC）之间的协同作用，实现了自动启发式设计（AHD）。在进化框架内思维和代码的共同演化提供了出色的AHD性能，同时降低了计算成本。

以下图显示了AEL在在线装箱问题上的进化。我们概述了在进化过程中为获得最佳结果做出贡献的关键思路和相应的代码片段。此外，我们标记了导致改进的提示策略。最后，我们展示了最终种群中的最优启发式方法，并将其与人类设计的启发式方法以及来自FunSearch的方法进行了比较。

<img src="./docs/figures/evolution.jpg" alt="ael" width="1000" height="auto">

如果您对LLM&Opt或AEL感兴趣，可以：

1) 加入Wechat群 
1) 通过电子邮件fliu36-c@my.cityu.edu.hk联系我们。

如果您在使用代码时遇到任何困难，可以通过上述联系方式与我们联系或提交问题。

AEL和FunSearch在在线装箱问题上进行了比较，使用完全相同的预算（对LLM的2000次请求）和LLM（GPT-3.5）：

+ AEL
+ FunSearch: 我们的基准FunSearch，Deepmind的实现，我们对**FunSearch的复现代码在[这里](./baseline)**
+ 随机搜索: 没有进行进化的提示LLM
  每种方法运行三次

<img src="./docs/figures/compare.jpg" alt="ael" width="500" height="auto">

## 快速Web演示

我们准备了网页版本的Demo, 提供AEL的快速直观体验。

通过以下链接访问[Demo]()

## 使用AEL的示例

步骤1：安装AEL
cd aell

pip install .


步骤2：尝试示例：TSP的构造算法

在开始之前，请设置远程LLM的密钥或设置本地LLM！ text

cd examples/greedy_tsp

python runAEL.py

#### [参数设置]

+ LLM大模型参数
  api_endpoint = "oa.api2d.site" # LLM API的终端点
  api_key = "your key" # 使用您的密钥 # 您的API密钥

  llm_model = "gpt-3.5-turbo-1106" # LLM模型

+ 输入和输出参数

  output_path = "./" # AEL输出的默认路径
  'use_seed' : True, # 如果使用种子算法
  'seed_path' : output_path+"/ael_seeds/seeds.json", # 种子算法的路径
  "use_pop" : False, # 如果使用现有的初始种群

  "pop_path" : output_path+"/ael_results/pops/population_generation_0.json", # 初始种群的路径 "n_pop_initial": 0 # 与路径对齐的种群数量

+ 进化参数

  pop_size = 5 # 每个种群中的算法数量，默认=5
  n_pop = 5 # 种群数量，默认=5
  operators = ['e1','e2','m1','m2'] # 进化操作员：['e1','e2','m1','m2']
  m = 2 # 'e1'和'e2'操作员的父母数量，默认=2

  operator_weights = [1,1,1,1] # 操作员的权重，即每次迭代使用操作员的概率，默认=[1,1,1,1]

+ 调试模型
+ debug_mode = False # 如果调试

## 更多使用AEL的示例（代码和论文）

+ 组合优化
  在线装箱，贪心启发式方法，代码, [论文]
  TSP，构造启发式方法，代码, [论文]
  TSP，引导局部搜索，[代码], [论文]
  Flow Shop调度问题（FSSP），引导局部搜索，[代码], [论文]
+ 机器学习
  攻击，代码, 论文
+ 贝叶斯优化
  即将推出

## 如何在您的应用程序中使用AEL

详细的逐步指南在这里提供

## 大模型部署

1. 远程LLM + API（例如，GPT3.5，GPT4）： + API2D (https://api2d.com/) 或OpenAI接口适用于GPT3.5和GPT4（付费） + 可在此处找到其他API

2. 本地LLM部署 + API（例如，Llamacode，instruct Llama，gemma，deepseek，...）：

   + 步骤1：下载Huggingface模型，例如，下载gemma-2b-it（git clone https://huggingface.co/google/gemma-2b-it） 

   + 步骤2： + cd llm_server + python gemma_instruct_server.py 
   + 步骤3： 将运行服务器生成的URL复制到request.py（例如，将url='http://127.0.0.1:11012/completions'设置为测试您的服务器部署的URL） 
   + 步骤4： 将运行服务器生成的URL复制到您的示例中的runAEL.py中（例如，将url='http://127.0.0.1:11012/completions'设置为runAEL.py） 
   + 步骤5： Python runAEL.py 3) 您的实现： + 如果您想使用其他LLM或自己的GPT API或本地LLM，请在ael/llm中添加您的接口

## 参考论文

1. **AEL**:  "Fei Liu, Xialiang Tong, Mingxuan Yuan, and Qingfu Zhang, Algorithm Evolution Using Large Language Model. arXiv preprint arXiv:2311.15249. 2023."  https://arxiv.org/abs/2311.15249
2. **Guided Local Search:** "Fei Liu, Xialiang Tong, Mingxuan Yuan, Xi Lin, Fu Luo, Zhenkun Wang, Zhichao Lu, and Qingfu Zhang, [An Example of Evolutionary Computation+ Large Language Model Beating Human: Design of Efficient Guided Local Search](https://arxiv.org/abs/2401.02051)" https://arxiv.org/abs/2401.02051
3. **Adversarial Attacks:** Pin Guo, Fei Liu, Xi Lin, Qingchuan Zhao, and Qingfu Zhang,  L-AutoDA: Leveraging Large Language Models for Automated Decision-based Adversarial Attacks. *arXiv preprint arXiv:2401.15335*. 2024.

## License

MIT
