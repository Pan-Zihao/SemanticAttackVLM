import numpy as np

def select_next_node(current_node, destination_node, unvisited_nodes, distance_matrix):
    angles = []
    for node in unvisited_nodes:
        vector_current_to_node = distance_matrix[current_node][node]
        vector_current_to_destination = distance_matrix[current_node][destination_node]
        angle = np.arccos(np.dot(vector_current_to_node, vector_current_to_destination) / (np.linalg.norm(vector_current_to_node) * np.linalg.norm(vector_current_to_destination)))
        unvisited_neighbors = np.count_nonzero(distance_matrix[node][unvisited_nodes] < np.inf)
        score = angle + unvisited_neighbors
        angles.append(score)
    next_node = unvisited_nodes[np.argmin(angles)]
    return next_node