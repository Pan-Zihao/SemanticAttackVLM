

aaaaaa
import gradio as gr
from ael import ael
from ael.utils import createFolders
import sys
import ast

### output path ###
output_path = "./" # default for ael outputs
createFolders.create_folders(output_path)

load_data = {
    "is_load" : False,
    "path" : output_path+"/ael_results/pops/population_generation_0.json",
    "n_pop_initial": 0
    }

debug_mode = False # if debug

def wrapper(api_endpoint, api_key, llm_model, pop_size, n_pop, operators, m, operator_weights):

    algorithmEvolution = ael.AEL(api_endpoint,api_key,llm_model,pop_size,n_pop,operators,m,ast.literal_eval(operator_weights),load_data,output_path,debug_mode)

    algorithmEvolution.run()


class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "w")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        
    def flush(self):
        self.terminal.flush()
        self.log.flush()
        
    def isatty(self):
        return False 
    
sys.stdout = Logger("output.log")

def read_logs():
    sys.stdout.flush()
    with open("output.log", "r") as f:
        return f.read()

# 界面
title = """<h1 align="center">Learning Optimization & Foundation Models</h1>"""
description = """
<h2 align="center">AEL: Algorithm Evolution using Large Language Model</h2>
"""
article = """Please find more details in [original paper](https://arxiv.org/abs/2311.15249).
<div align="center">
<img src="https://raw.githubusercontent.com/yzy1996/Image-Hosting/master/202401122333028.png" width=600px>
</div>
"""

demo = gr.Blocks()

with demo:
    gr.HTML(title)
    gr.HTML(description)

    with gr.Row():
        pop_size = gr.Number(value=5, label="Popopulation Size")
        n_pop = gr.Number(value=10, label="Number of Populations")
        m = gr.Number(value=2, label="Number of Parents")

    with gr.Row():
        operators = gr.CheckboxGroup(choices=['e1','e2','m1','m2'], 
                                     value=['e1','e2','m1','m2'],
                                     label="Evolution Operators")
        
        operator_weights = gr.Textbox(value=[1,1,1,1], 
                                      label="Weights for Operators")

    with gr.Row():
        api_endpoint = gr.Dropdown(label="Choose or Enter the Request Entry", 
                                   choices=["oa.api2d.net", "api.openai.com", "openai.api2d.net"], 
                                   value=0, allow_custom_value=True)
        api_key = gr.Textbox(label="Enter your API Key", value="")
        llm_model = gr.Dropdown(label="Choose or Enter the Model Name", 
                                choices=["gpt-3.5-turbo-1106", "gpt-4-0613"], 
                                value=0, allow_custom_value=True)
    
    start_btn = gr.Button("Run")
    stop_btn = gr.Button("stop")

    click_event = start_btn.click(wrapper, inputs=[api_endpoint, api_key, llm_model, pop_size, n_pop, operators, m, operator_weights], outputs=[])

    logs = gr.Textbox(max_lines=5, label="Outputs")
    demo.load(read_logs, None, logs, every=1)
    gr.Markdown(article)

demo.queue().launch()


