import json

def get_output(file_path='./ael_results/combined_results.json'):
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)

    code_list = [entry["code"] for entry in data.values()]

    return code_list

def create_seed_json(code_list, objective_list, output_file):
    # 确保两个列表的长度相同
    if len(code_list) != len(objective_list):
        raise ValueError("code_list和objective_list的长度必须相同")

    # 构建JSON数据结构
    seed_data = []
    for code, objective in zip(code_list, objective_list):
        entry = {
            "algorithm": "",
            "code": code,
            "objective": objective,
            "other_inf": None
        }
        seed_data.append(entry)

    # 将数据写入JSON文件
    with open(output_file, 'w', encoding='utf-8') as file:
        json.dump(seed_data, file, ensure_ascii=False, indent=4)

#例子：
code_list = [
    "a picture of a blue dog wearing sunglasses in the style of realistic. It is sitting on the beach in the moon on a snowy day, it is drinking a bottle of cola. There are many medieval castles around and many spaceships in the sky.",
    "a picture of a blue dog wearing sunglasses in the style of realistic. It is sitting on the beach in the moon on a snowy day, it is drinking a bottle of cola. There are many medieval castles around and many spaceships in the sky.",
    "a picture of a blue dog wearing sunglasses in the style of realistic. It is sitting on the beach in the moon on a snowy day, it is drinking a bottle of cola. There are many medieval castles around and many spaceships in the sky."
]

objective_list = [1.47, 1.47, 1.47]

# 输出文件路径
output_file = './ael_seeds/seeds.json'

# 调用函数生成seed.json文件
create_seed_json(code_list, objective_list, output_file)


print(get_output())
