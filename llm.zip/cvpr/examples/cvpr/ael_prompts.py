
class GetPrompts():
    def __init__(self):
        self.prompt_task = "You need to change the caption in the equation."
        self.prompt_func_name = "captionUpdate"
        self.prompt_func_inputs = [""]
        self.prompt_func_outputs = ["caption"]
        self.prompt_inout_inf = "You only need to change the content of the caption in the method."

        self.prompt_other_inf = "return caption:The changed value"

    def get_task(self):
        return self.prompt_task
    
    def get_func_name(self):
        return self.prompt_func_name
    
    def get_func_inputs(self):
        return self.prompt_func_inputs
    
    def get_func_outputs(self):
        return self.prompt_func_outputs
    
    def get_inout_inf(self):
        return self.prompt_inout_inf

    def get_other_inf(self):
        return self.prompt_other_inf

if __name__ == "__main__":
    getprompts = GetPrompts()
    print(getprompts.get_task())
