#import importlib
#heuristic_module = importlib.import_module("add")
#eva = importlib.reload(heuristic_module)

import http.client
import json
import openai
#def sum(eva,a,b,c):
#    print(eva(a,b,c)+10)
#    return eva(a,b,c)+10
#sum(eva,1,2,3)

def get_response(prompt_content):
    BASE_URL = "https://api.xiaoai.plus/v1"
    OPENAI_API_KEY = "sk-UqhYLLaRGhqbMA4bAaEa329e0eEd4a8f9fE5578cB07178Ac"
    client = openai.OpenAI(
        api_key=OPENAI_API_KEY,
        base_url=BASE_URL,
    )
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        temperature=0,
        max_tokens=500,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0,
        messages=[
            {"role": "user", "content": prompt_content}
        ]
    )

    return response.choices[0].message.content

print(get_response("你是谁"))