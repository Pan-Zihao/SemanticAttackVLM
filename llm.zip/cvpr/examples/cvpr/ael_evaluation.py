
import time
import random
class Evaluation():
    def __init__(self) -> None:
        print("begin evaluate")
    def evaluate(self):
        time.sleep(1)
        try:
            with open("caption.txt", "r", encoding="utf-8") as file:
                caption = file.read()
            score = get_score(caption)
            return score
        except Exception as e:
            print("Error:",str(e))
            return None


def get_score(caption):
    print(caption)
    fitness = 1 + random.random()
    return fitness