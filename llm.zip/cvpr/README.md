
<br>

<div align=center>
<h1 align="center">
<img src="docs/figures/logo.png" width="50"> AEL Algorithm Evolution using Large Language Model
</h1>
  
[Chinese Version 中文版本](./README_CN.md)

[![Github][Github-image]][Github-url]
[![License][License-image]][License-url]
[![Releases][Releases-image]][Releases-url]
[![Web Demo][Installation-image]][Web Demo-url]
[![Wiki][Wiki-image]][Wiki-url]


[Github-image]: https://img.shields.io/badge/github-12100E.svg?style=flat-square
[License-image]: https://img.shields.io/badge/License-MIT-orange?style=flat-square
[Releases-image]: https://img.shields.io/badge/Release-Version_1.0-blue?style=flat-square
[Installation-image]: https://img.shields.io/badge/Web_Demo-Version_1.0-blue?style=flat-square
[Wiki-image]: https://img.shields.io/badge/Docs-参考文档-black?style=flat-square


[Github-url]: https://github.com/FeiLiu36/AEL
[License-url]: https://github.com/FeiLiu36/AEL/blob/main/LICENSE
[Releases-url]: https://github.com/FeiLiu36/AEL/releases
[Web Demo-url]: https://github.com/FeiLiu36/AEL/ael/app/
[Wiki-url]: https://github.com/FeiLiu36/AEL/tree/main/docs



</div>
<br>



This code provides a framework for **Evolutionary Computation** + **Large Language Model** for automatic algorithm design.

<img src="./docs/figures/ael.jpg" alt="ael" width="600" height="280">

## Introduction



Heuristics are indispensable for tackling complex search and optimization problems. However, manual heuristic design is tedious and demands significant human intuition and experience. 

AEL introduces a novel paradigm that leverages the synergy between Large Language Models (LLMs) and Evolutionary Computation (EC) for Automatic Heuristic Design (AHD). The coevolution of thoughts and codes within an evolutionary framework offers superior AHD performance while mitigating computational expenses. 

AEL design very competetive algorithm/heuristic in minuts/hours.  Notably, It surpasses FunSearch, identifying superior heuristics with $1000\times$ fewer computational budgets (i.e., queries to LLMs) on online bin packing problem.

Following Figure shows the Evolution of AEL on the online bin packing problem. We outline the key **thoughts** and the corresponding **code** **snippets** that have contributed to the best results during evolution. Additionally, we mark the prompt strategies that result in improvement. Finally, we present the optimal heuristic in the final population and compare it to the heuristics designed by humans and from FunSearch.

<img src="./docs/figures/evolution.jpg" alt="ael" width="1000" height="auto">



If you are interested on LLM&Opt or AEL, you can:

1) Join Wechat Group
2) Contact us through email fliu36-c@my.cityu.edu.hk.

If you encounter any difficulty using the code, you can contact us through the above or submit an [issue] 



A Comparison between AEL and FunSearch on Online Bin Packing Problem using exactly same budget (2000 requests to LLM) and LLM (GPT-3.5)

+ AEL
+ FunSearch: Our implementation of **FunSearch, Deepmind** as the baseline, can be found [here](./baseline)
+ Random Search: prompt LLM without evolution
+ Three runs for each approach

<img src="./docs/figures/compare.jpg" alt="ael" width="500" height="auto">

## A Quick Web Demo

A Quick Web Demo can be found [here](./ael/ap)





## Examples using AEL

#### Step 1: Install AEL

```bash
cd aell

pip install .
```

#### Step 2: Try Example: Constructive Algorithm for TSP

**<span style="color: red;">Setup your Key for remote LLM or Setup your local LLM before start !</span>**  <code style="color : name_color">text</code>

```bash

cd examples/greedy_tsp

python runAEL.py
```



## Settings

+ **LLM**
  + api_endpoint = "oa.api2d.site"   # endpoint for LLM API
  + api_key = "your key" # use your key   # your API key
  + llm_model = "gpt-3.5-turbo-1106"    # LLM model

+ **Input and output** 
  + output_path = "./" # default path for ael outputs
  + 'use_seed' : True,  # if use seed algorithm
  + 'seed_path' : output_path+"/ael_seeds/seeds.json",  # path for seed algorithm
  + "use_pop" : False,   # if use existing initial population
  + "pop_path" : output_path+"/ael_results/pops/population_generation_0.json",   # path for initial population
        "n_pop_initial": 0   # number of pop which, align with path
        

+ **Evolution**
  + pop_size = 5 # number of algorithms in each population, default = 5
  + n_pop = 5 # number of populations, default = 5
  + operators = ['e1','e2','m1','m2']  # evolution operators: ['e1','e2','m1','m2']
  + m = 2  # number of parents for 'e1' and 'e2' operators, default = 2
  + operator_weights = [1,1,1,1] # weights for operators, i.e., the probability of use the operator in each iteration , default = [1,1,1,1]

+ **Debug model**
  + debug_mode = False # if debug



### More Examples using AEL (Code & Paper)

#### Combinatorial Optimization

1. Online Bin Packing, greedy heuristic, [code](./ael/examples/online_bin_packing), [paper]
2. TSP, construct heuristic, [code](./ael/examples/greedy_tsp), [paper]
3. TSP, guided local search, [code], [paper]
4. Flow Shop Scheduling Problem (FSSP), guided local search, [code], [paper]

#### Machine Learning

1. Attack, , [code](./ael/examples/L_AutoDA), [paper](https://arxiv.org/abs/2401.15335)

#### Bayesian Optimization

1. Comming soon





## Use AEL in You Application

A Step-by-step guide is provided in [here](./docs/QuickGuide.md)





## LLMs

1) Remote LLM + API (e.g., GPT3.5, GPT4):
   + API2D (https://api2d.com/) or OpenAI interface for GPT3.5 and GPT4. (Paid)
   + Other APIs can be found [here]()

2) Local LLM Deployment + API (e.g., Llamacode, instruct Llama, gemma, deepseek, ...):
   + Step 1: Download Huggingface Model, for example, download gemma-2b-it (git clone https://huggingface.co/google/gemma-2b-it)
   + Step 2: 
     + cd llm_server
     + python gemma_instruct_server.py
   + Step 3: Copy your url generated by running your server to request.py ( For example, set url='http://127.0.0.1:11012/completions') to test your server deployment. 
   + Step 4: Copy your url generated by running your server to runAEL.py in your example. (For example, set url='http://127.0.0.1:11012/completions')
   + Step 5: Python runAEL.py
3) Your Implementation: 
   + If you want to use other LLM or if you want to use your own GPT API or local LLMs, please add your interface in ael/llm



## Reference Papers

1. **AEL**:  "Fei Liu, Xialiang Tong, Mingxuan Yuan, and Qingfu Zhang, Algorithm Evolution Using Large Language Model. arXiv preprint arXiv:2311.15249. 2023."  https://arxiv.org/abs/2311.15249
2. **Guided Local Search:** "Fei Liu, Xialiang Tong, Mingxuan Yuan, Xi Lin, Fu Luo, Zhenkun Wang, Zhichao Lu, and Qingfu Zhang, [An Example of Evolutionary Computation+ Large Language Model Beating Human: Design of Efficient Guided Local Search](https://arxiv.org/abs/2401.02051)" https://arxiv.org/abs/2401.02051
3. **Adversarial Attacks:** Pin Guo, Fei Liu, Xi Lin, Qingchuan Zhao, and Qingfu Zhang,  L-AutoDA: Leveraging Large Language Models for Automated Decision-based Adversarial Attacks. *arXiv preprint arXiv:2401.15335*. 2024.



## License

MIT
