import openai
def get_response(prompt_content):
    BASE_URL = "https://api.chatgptid.net/v1"
    OPENAI_API_KEY = "sk-oztvw2gifcNPZQ4bF2E59eDa1b4e4dA5AeE3B562Ce3fA4Dd"
    client = openai.OpenAI(
        api_key=OPENAI_API_KEY,
        base_url=BASE_URL,
    )
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": prompt_content}
        ]
    )

    return response.choices[0].message.content

print(get_response("1+1=?"))